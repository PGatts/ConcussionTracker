// Lab 2, uP2 Fall 2025 SOLUTIONS
// Created: 2023-07-31
// Updated: 2025-06-06
// Lab 2 is intended to be a basic introduction to a widely used communication protocol
// known as I2C. This protocol is useful in it's ability to have a large swath of
// peripherals connected to it at a time such as sensors.

/************************************Includes***************************************/

#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <stdio.h>



#include <driverlib/interrupt.h>
#include <driverlib/sysctl.h>
#include <driverlib/gpio.h>
#include <driverlib/timer.h>
#include <inc/hw_memmap.h>
#include <inc/hw_types.h>
#include <driverlib/ssi.h>
#include <driverlib/pin_map.h>


#include "./MultimodDrivers/multimod.h"
#include "./MultimodDrivers/multimod_spi.h"
#include "./MultimodDrivers/multimod_ST7789.h"
#include "./MultimodDrivers/GFX_Library.h"


/************************************Includes***************************************/

/*************************************Defines***************************************/
/*************************************Defines***************************************/

/********************************Public Variables***********************************/
/********************************Public Variables***********************************/

/**************************************MAIN*******************************************/
#define delay_0_1_s     1600000
/************************************MAIN*******************************************/
 volatile int flash = 1;
 volatile int twopass = 0;
 static uint8_t x_f = 25;
 static uint8_t y_s = 225;
 int32_t MAG;

 uint32_t mag_gyro;

 int16_t was_happy=0;
 int16_t red_led =0;
 int16_t X_ACCEL=0;
 int16_t Y_ACCEL=0;
 int16_t Z_ACCEL=0;

 int16_t happy=1;

 int16_t X_GY=0;
 int16_t Y_GY=0;
 int16_t Z_GY=0;
 float MAG_X;
 uint16_t faceColor   = 0;
 uint16_t eyeColor    = 0;
 uint16_t mouthColor  = 0;
 uint16_t tearColor   = 0;     // blue tears
 uint16_t eyeWhite    = 0; // white

 uint16_t count=0;



 int angle;
 void draw_happy_face(void) {

     // 1. Draw rectangle border
     //display_drawRect(40, 40, 160, 160, borderColor);

     // 2. Draw face background (big circle)
     display_fillCircle(120, 120, 70, faceColor);

     // 3. Draw eyes
     display_fillCircle(95, 140, 14, display_color565(255, 255, 255));   // left eye
     display_fillCircle(145, 140, 14, display_color565(255, 255, 255));  // right eye

     display_fillCircle(95, 135, 8, eyeColor);   // left eye
     display_fillCircle(145, 135, 8, eyeColor);  // right eye

     // 4. Draw smiling mouth (arc approximation)
     // Simple method: draw a circle outline but only the lower part

     int x;
     int y;
     for (angle = 200; angle <= 340; angle += 5) {
         x = 120 + (int)(40 * cos(angle * 3.14 / 180.0));
         y = 120 + (int)(40 * sin(angle * 3.14 / 180.0));
         display_fillCircle(x, y, 2, mouthColor);
     }
 }

 void draw_happy_face_halfblink(void) {


     display_fillCircle(120, 120, 70, faceColor);

     // half-closed: draw rectangles over top part of the eyeball
     display_fillCircle(95, 140, 14, display_color565(255, 255, 255));
     display_fillCircle(145, 140, 14, display_color565(255, 255, 255));
     // eyelids: yellow bar across eyes
     display_fillRect(81, 133, 28, 8, faceColor);
     display_fillRect(131, 133, 28, 8, faceColor);

     // pupils slightly covered
     display_fillCircle(95, 140, 6, eyeColor);
     display_fillCircle(145, 140, 6, eyeColor);

     // mouth arc
     for (angle = 200; angle <= 340; angle += 5) {
         int x = 120 + (int)(40 * cos(angle * 3.14 / 180.0));
         int y = 120 + (int)(40 * sin(angle * 3.14 / 180.0));
         display_fillCircle(x, y, 2, mouthColor);
     }
 }

 void draw_happy_face_closed(void) {


     display_fillCircle(120, 120, 70, faceColor);

     // closed eyes as black lines
     display_drawLine(81, 140, 109, 140, eyeColor);   // left
     display_drawLine(131, 140, 159, 140, eyeColor);  // right

     // mouth arc
     for (angle = 200; angle <= 340; angle += 5) {
         int x = 120 + (int)(40 * cos(angle * 3.14 / 180.0));
         int y = 120 + (int)(40 * sin(angle * 3.14 / 180.0));
         display_fillCircle(x, y, 2, mouthColor);
     }
 }
 void draw_crying_face_open(void) {



     // Face background
     display_fillCircle(120, 120, 70, faceColor);

     // Eyes
     display_fillCircle(95, 140, 14, eyeWhite);   // left eye
     display_fillCircle(145, 140, 14, eyeWhite);  // right eye
     display_fillCircle(95, 140, 6, eyeColor);    // pupil left
     display_fillCircle(145, 140, 6, eyeColor);   // pupil right



     // Tears (first drop position)
     display_fillCircle(95, 115, 4, tearColor);   // left tear
     display_fillCircle(145, 115, 4, tearColor);  // right tear

     // Frown mouth (arc, opposite direction of smile)
     for (angle = 20; angle <= 160; angle += 5) {
         int x = 120 + (int)(40 * cos(angle * 3.14 / 180.0));
         int y = 80 + (int)(20 * sin(angle * 3.14 / 180.0));
         display_fillCircle(x, y, 2, mouthColor);
     }
 }


 void draw_crying_face_tears_mid(void) {


     display_fillCircle(120, 120, 70, faceColor);

     // Eyes half closed (eyelids)
     display_drawLine(81, 145, 109, 135, eyeColor);   // left
     display_drawLine(131, 135, 159, 145, eyeColor);  // right
     // Tears (mid fall)
     display_fillCircle(95, 115, 4, tearColor);   // left tear
          display_fillCircle(145, 115, 4, tearColor);  // right tear

     display_fillCircle(95, 105, 4, tearColor);
     display_fillCircle(145, 105, 4, tearColor);

     // Frown
     for (angle = 20; angle <= 160; angle += 5) {
         int x = 120 + (int)(40 * cos(angle * 3.14 / 180.0));
         int y = 80 + (int)(20 * sin(angle * 3.14 / 180.0));
         display_fillCircle(x, y, 2, mouthColor);
     }
 }


 void draw_crying_face_tears_low(void) {
     display_fillCircle(120, 120, 70, faceColor);

     // Eyes fully closed (lines)
     display_drawLine(81, 142, 109, 138, eyeColor);   // left
     display_drawLine(131, 138, 159, 142, eyeColor);  // right

     display_fillCircle(95, 105, 4, tearColor);
          display_fillCircle(145, 105, 4, tearColor);
     // Tears (lower position)
     display_fillCircle(95, 90, 4, tearColor);
     display_fillCircle(145, 90, 4, tearColor);

     // Frown
     for (angle = 20; angle <= 160; angle += 5) {
         int x = 120 + (int)(40 * cos(angle * 3.14 / 180.0));
         int y = 60 + (int)(20 * sin(angle * 3.14 / 180.0));
         display_fillCircle(x, y, 2, mouthColor);
     }
 }




int main(void) {
    faceColor   = display_color565(0, 255, 0);
    eyeColor    = display_color565(0, 0, 0);
    mouthColor  = display_color565(255, 0, 0);
    tearColor   = display_color565(0, 0, 255);     // blue tears
    eyeWhite    = display_color565(255, 255, 255); // white

    //Sets clock speed to 80 MHz. You'll need it!
    SysCtlClockSet(SYSCTL_SYSDIV_2_5 | SYSCTL_USE_PLL | SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);
    IntMasterDisable();
    SysCtlDelay(10);

    // Enable relevant port for launchpad switches
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);

    // Configure SW1 input
    GPIOPinTypeGPIOInput(GPIO_PORTF_BASE, (GPIO_PIN_4));
    GPIOPinTypeGPIOInput(GPIO_PORTF_BASE, GPIO_PIN_0);
    GPIOUnlockPin(GPIO_PORTF_BASE, GPIO_PIN_0);
    GPIODirModeSet(GPIO_PORTF_BASE, GPIO_PIN_0 | GPIO_PIN_4, GPIO_DIR_MODE_IN);
    // Enable weak pull-ups on PF0 and PF4 (switches)
    GPIOPadConfigSet(GPIO_PORTF_BASE,
                     GPIO_PIN_0 | GPIO_PIN_4,
                     GPIO_STRENGTH_2MA,
                     GPIO_PIN_TYPE_STD_WPU);



    SPI_Init(SSI0_BASE);
    UART_Init();
    I2C_Init(I2C1_BASE);
    BMI160_Init();
    OPT3001_Init();


    UART_Init();
    //| I2C_Init(I2C1_BASE) | BMI160_Init() | OPT3001_Init() | SPI_Init();

    ST7789_Init();
    ST7789_BackLight_on();
    ST7789_Select();
    ST7789_WriteData(0xF8);  // red MSB
    ST7789_WriteData(0x00);  // red LSB
    ST7789_Deselect();




    uint32_t light;
    ST7789_Fill(ST7789_BLACK);  // red LSB




    y_s -=20;
    //GPIOPinTypeGPIOInput(GPIO_PORTF_BASE, (GPIO_PIN_4));


    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_TIMER0));
    TimerConfigure(TIMER0_BASE, TIMER_CFG_PERIODIC);
    uint32_t ui32Period = (SysCtlClockGet() / 10);
    TimerLoadSet(TIMER0_BASE, TIMER_A, ui32Period-1);

    TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
    IntEnable(INT_TIMER0A);
    TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
    IntMasterEnable();

    TimerEnable(TIMER0_BASE, TIMER_A);

    draw_happy_face();


    while(true) {


        ST7789_Select();

        X_ACCEL = BMI160_AccelXGetResult();
        Y_ACCEL = BMI160_AccelYGetResult();
        Z_ACCEL = BMI160_AccelZGetResult();

        MAG_X = 16.67/32767*(sqrtf((float)(X_ACCEL * X_ACCEL) + (float)(Y_ACCEL * Y_ACCEL) + (float)(Z_ACCEL * Z_ACCEL)));

        X_GY = BMI160_GyroXGetResult();
        Y_GY = BMI160_GyroYGetResult();
        Z_GY = BMI160_GyroZGetResult();





        if (happy == 1){
            if (was_happy == 0){
                ST7789_Fill(ST7789_BLACK);
            }

            draw_string(x_f+65,y_s,"HAPPY HEAD",display_color565(0,255,0),ST7789_BLACK,1);
            faceColor   = display_color565(0, 255, 0);
            mouthColor  = display_color565(255, 0, 0);
            draw_happy_face();
            SysCtlDelay(16000000 / 3 * 4);   // ~2s delay

            // Half closed
            draw_happy_face_halfblink();
            SysCtlDelay(160000 / 3 * 26);    // ~100ms

            // Fully closed
            draw_happy_face_closed();
            SysCtlDelay(160000 / 3 * 26);    // ~100ms

            // Half closed again
            draw_happy_face_halfblink();
            SysCtlDelay(160000 / 3 * 35);    // ~150m

            was_happy = 1;
        }
        else{
            if (was_happy == 1){
                            ST7789_Fill(ST7789_BLACK);
                        }

            draw_string(x_f+72,y_s,"HIT HARD",display_color565(255,0,0),ST7789_BLACK,1);
            faceColor   = display_color565(255, 0, 0);
            mouthColor  = display_color565(0, 0, 0);
            draw_crying_face_open();
            SysCtlDelay(16000000 / 3 * 2);   // ~1s delay

            draw_crying_face_tears_mid();
            SysCtlDelay(160000 / 3 * 26);    // ~100ms

            draw_crying_face_tears_low();
            SysCtlDelay(160000 / 3 * 26);    // ~100ms

            draw_crying_face_tears_mid();
            SysCtlDelay(160000 / 3 * 35);    // ~150ms

            was_happy = 0;
            draw_string(x_f+45,25,"PLAYER 67 INJURED",display_color565(255,0,0),ST7789_BLACK,1);
        }




    }
}



void Timer0A_Handler(void) {

    TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);

    flash = 1;
    MAG_X = 100.0f *16.67f / 32767.0f*(sqrtf((float)(X_ACCEL * X_ACCEL) + (float)(Y_ACCEL * Y_ACCEL) + (float)(Z_ACCEL * Z_ACCEL)));
    mag_gyro = (uint32_t)(100*sqrtf((float)(X_GY * X_GY) + (float)(Y_GY * Y_GY) + (float)(Z_GY * Z_GY))) / 16.4f;

    //UARTprintf("MAG: %d\n", MAG_X);
    UARTprintf("MAG_GY: %d\n", mag_gyro);

    if (MAG_X >= 200 || mag_gyro >= 15000){
        count=50;
        happy = 0;
    }
    if (count >0){
        count--;
        if (count== 0){
                happy = 1;
            }
    }





    UARTprintf("MAG: %d\n", (int32_t)(MAG_X));


}

