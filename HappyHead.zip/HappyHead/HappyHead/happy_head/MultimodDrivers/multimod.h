#ifndef MULTIMOD_H_
#define MULTIMOD_H_

#include "multimod_BMI160.h"
#include "multimod_i2c.h"
#include "multimod_OPT3001.h"
#include "multimod_uart.h"

static void multimod_init() {
    // your code here
    

}

#endif /* MULTIMOD_H_ */
