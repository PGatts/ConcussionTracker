// multimod_BMI160.c
// Date Created: 2023-07-25
// Date Updated: 2023-07-27
// Defines for BMI160 functions

/************************************Includes***************************************/

#include "../multimod_BMI160.h"

#include <stdint.h>
#include "../multimod_i2c.h"

/************************************Includes***************************************/

/********************************Public Functions***********************************/

// BMI160_Init
// Initializes the BMI160. Currently enables the accelerometer
// in full-power mode.
// Return: void
void BMI160_Init() {
    I2C_Init(I2C_A_BASE);

    // Power on accelerometer
    BMI160_WriteRegister(BMI160_CMD_ADDR, BMI160_ACCEL_NORMAL_MODE);

    //Power on Gyroscope
    BMI160_WriteRegister(BMI160_CMD_ADDR, BMI160_GYRO_NORMAL_MODE);

    //Configure Accelerometer for no undersampling, normal bandwidth parameter, and 800 Hz output rate
    BMI160_WriteRegister(BMI160_ACCCONF_ADDR, BMI160_ACC_US_OFF | BMI160_ACC_BWP_NORMAL | BMI160_ACC_ODR_800HZ);

    //Configure Accelerometer for 16g range
    BMI160_WriteRegister(BMI160_ACCRANGE_ADDR, BMI160_ACC_RANGE_16G);

    //Configure Gyroscope for normal bandwidth parameter and 3200 Hz Output rate
    BMI160_WriteRegister(BMI160_GYRCONFG_ADDR, BMI160_GYR_BWP_NORMAL | BMI160_ACC_ODR_3200HZ);

    //Configure Gyroscope for 16g range
    BMI160_WriteRegister(BMI160_GYRRANGE_ADDR, BMI160_GYRO_RANGE_2000);

    
    return;
}

// BMI160_Init
// Writes to a register address in the BMI160.
// Param uint8_t "addr": Register address
// Param uint8_t "data": data to write
// Return: void
void BMI160_WriteRegister(uint8_t addr, uint8_t data) {
    // write a single register
    // write where?
            // your code here

    uint8_t temp[2]= {addr,data};

    // with what? (hint youre writing only 1 data item, but you still need to specify where)
            // your code here

    // write I2C device
    //void I2C_WriteMultiple(uint32_t mod, uint8_t addr, uint8_t* data, uint8_t num_bytes)

    I2C_WriteMultiple(I2C_A_BASE, BMI160_ADDR, temp, 2);
}

// BMI160_ReadRegister
// Reads from a register address in the BMI160.
// Param uint8_t "addr": Register address
// Return: void
uint8_t BMI160_ReadRegister(uint8_t addr) {
    // read from which addr?

    I2C_WriteSingle(I2C_A_BASE,BMI160_ADDR, addr);

    // your code here
    uint8_t temp = I2C_ReadSingle(I2C_A_BASE,BMI160_ADDR);

    // return the data
    return temp; // your code here
}

// BMI160_MultiReadRegister
// Uses the BMI160 auto-increment function to read from multiple registers.
// Param uint8_t "addr": beginning register address
// Param uint8_t* "data": pointer to an array to store data in
// Param uint8_t "num_bytes": number of bytes to read
// Return: void
void BMI160_MultiReadRegister(uint8_t addr, uint8_t* data, uint8_t num_bytes) {


    // write to which addr?


    I2C_WriteSingle(I2C_A_BASE,BMI160_ADDR, addr);
    // your code here

    //void I2C_ReadMultiple(uint32_t mod, uint8_t addr, uint8_t* data, uint8_t num_bytes)
    I2C_ReadMultiple(I2C_A_BASE,BMI160_ADDR,data,num_bytes);
    // your code here

    return;
}

// BMI160_AccelXGetResult
// Gets the 16-bit x-axis acceleration result.
// Return: uint16_t
int16_t BMI160_AccelXGetResult() {

    // if not read, wait till read
    while(!(BMI160_ReadRegister(BMI160_STATUS_ADDR)&0x80));


    // read data
    uint8_t x_l = BMI160_ReadRegister(0x12);
    uint8_t x_h = BMI160_ReadRegister(0x13);
    int16_t Accel_X_T = (int16_t)((x_h<<8)|x_l);


    return (Accel_X_T);
}

// BMI160_AccelYGetResult
// Gets the 16-bit y-axis acceleration result.
// Return: uint16_t
int16_t BMI160_AccelYGetResult() {

    // if not read, wait till read
    while(!(BMI160_ReadRegister(BMI160_STATUS_ADDR)&0x80));


    // read data
    uint8_t y_l = BMI160_ReadRegister(0x14);
    uint8_t y_h = BMI160_ReadRegister(0x15);
    int16_t Accel_y_T = (int16_t)((y_h<<8)|y_l);


    return (Accel_y_T);
}

// BMI160_AccelZGetResult
// Gets the 16-bit z-axis acceleration result.
// Return: uint16_t
int16_t BMI160_AccelZGetResult() {

    // if not read, wait till read
    while(!(BMI160_ReadRegister(BMI160_STATUS_ADDR)&0x80));


    // read data
    uint8_t z_l = BMI160_ReadRegister(0x16);
    uint8_t z_h = BMI160_ReadRegister(0x17);
    int16_t Accel_z_T = (int16_t)((z_h<<8)|z_l);


    return (Accel_z_T);

}

// BMI160_GyroXGetResult
// Gets the 16-bit x-axis gyroscope result.
// Return: uint16_t
int16_t BMI160_GyroXGetResult() {
    // if not read, wait till read
        // your code here

    // read data
        // your code here

    // write data 
        // your code here
    while(!(BMI160_ReadRegister(BMI160_STATUS_ADDR) & 0x40));

    // read data
    uint8_t x_l = BMI160_ReadRegister(0x0C);
    uint8_t x_h = BMI160_ReadRegister(0x0D);

    // combine into signed 16-bit
    int16_t Gyro_X_T = (int16_t)((x_h << 8) | x_l);

    return Gyro_X_T;

    //return (0/*your code here*/);
}

// BMI160_GyroYGetResult
// Gets the 16-bit y-axis gyroscope result.
// Return: uint16_t
int16_t BMI160_GyroYGetResult() {
    // if not read, wait till read
        // your code here

    // read data
        // your code here

    // write data 
        // your code here
    while(!(BMI160_ReadRegister(BMI160_STATUS_ADDR) & 0x40));

       uint8_t y_l = BMI160_ReadRegister(0x0E);
       uint8_t y_h = BMI160_ReadRegister(0x0F);

       int16_t Gyro_Y_T = (int16_t)((y_h << 8) | y_l);

       return Gyro_Y_T;

    //return (0/*your code here*/);
}

// BMI160_GyroZGetResult
// Gets the 16-bit z-axis gyroscope result.
// Return: uint16_t
int16_t BMI160_GyroZGetResult() {
    // if not read, wait till read
        // your code here

    // read data
        // your code here

    // write data 
        // your code here
    while(!(BMI160_ReadRegister(BMI160_STATUS_ADDR) & 0x40));

        uint8_t z_l = BMI160_ReadRegister(0x10);
        uint8_t z_h = BMI160_ReadRegister(0x11);

        int16_t Gyro_Z_T = (int16_t)((z_h << 8) | z_l);

        return Gyro_Z_T;

    //return (0/*your code here*/);
}

// BMI160_AccelXYZGetResult
// Stores the 16-bit XYZ accelerometer results in an array.
// Param uint16_t* "data": pointer to an array of 16-bit data.
// Return: void
void BMI160_AccelXYZGetResult(uint16_t* data) {
    // if not read, wait till read
        // your code here

    // read data
        // your code here

    // write data 
        // your code here

    return;
}

// BMI160_GyroXYZGetResult
// Stores the 16-bit XYZ gyroscope results in an array.
// Param uint16_t* "data": pointer to an array of 16-bit data.
// Return: void
void BMI160_GyroXYZGetResult(int16_t* data) {
    while(!(BMI160_ReadRegister(BMI160_STATUS_ADDR) & 0x08));

    uint8_t raw_data[6];

    BMI160_MultiReadRegister(BMI160_DATA_O + GYROX_O, raw_data, 6);

    data[0] = (raw_data[1] << 8) | raw_data[0];
    data[1] = (raw_data[3] << 8) | raw_data[2];
    data[2] = (raw_data[5] << 8) | raw_data[4];

    return;
}

// BMI160_GetDataStatus
// Gets the status register to determine if data is ready to read.
// Return: uint8_t
uint8_t BMI160_GetDataStatus() {
    // insert your code here
    return 0;
    //i added

}

/********************************Public Functions***********************************/
