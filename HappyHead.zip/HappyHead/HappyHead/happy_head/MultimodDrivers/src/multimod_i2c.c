// multimod_i2c.c
// Date Created: 2023-07-25
// Date Updated: 2023-07-27
// Defines for I2C functions

/************************************Includes***************************************/
#include <driverlib/pin_map.h>
#include "../multimod_i2c.h"

#include <driverlib/gpio.h>
#include <driverlib/sysctl.h>


#include <inc/tm4c123gh6pm.h>
#include <inc/hw_i2c.h>

/************************************Includes***************************************/

/********************************Public Functions***********************************/

// I2C_Init
// Initializes specified I2C module
// Param uint32_t "mod": base address of module
// Return: void
void I2C_Init(uint32_t mod) {
    // which I2C module?

    if (mod == I2C0_BASE){
        //Enable I2C0
        SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C0);

        //Enable PortB GPIO
        SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);

        //Wait for GPIO and I2C modules to be ready
        while(!SysCtlPeripheralReady(SYSCTL_PERIPH_I2C0));
        while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOB));

        //Set GPIO Pin to be used as I2C SDA
        GPIOPinTypeI2C(GPIO_PORTB_BASE,GPIO_PIN_3);

        //Set GPIO Pin for I2C SCK
        GPIOPinTypeI2CSCL(GPIO_PORTB_BASE,GPIO_PIN_2);

        //Enable I2C functionality on GPIO Port pins
        GPIOPinConfigure(GPIO_PB2_I2C0SCL);
        GPIOPinConfigure(GPIO_PB3_I2C0SDA );

        I2CMasterInitExpClk(I2C0_BASE, SysCtlClockGet(), false);

    }
    else if(mod == I2C1_BASE ){
        SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C1);

        SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

        while(!SysCtlPeripheralReady(SYSCTL_PERIPH_I2C1));
        while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOA));

        //Set GPIO Pin for SDA
        GPIOPinTypeI2C(GPIO_PORTA_BASE,GPIO_PIN_7);

        //Set GPIO Pin for SCK
        GPIOPinTypeI2CSCL(GPIO_PORTA_BASE,GPIO_PIN_6);

        GPIOPinConfigure(GPIO_PA6_I2C1SCL);
                GPIOPinConfigure(GPIO_PA7_I2C1SDA );

        I2CMasterInitExpClk(I2C1_BASE, SysCtlClockGet(), false);

    }
    else if(mod == I2C2_BASE){
        SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C2);

        SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);

        while(!SysCtlPeripheralReady(SYSCTL_PERIPH_I2C2));
        while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOE));

        //Set GPIO Pin for SDA
        GPIOPinTypeI2C(GPIO_PORTE_BASE,GPIO_PIN_5);

        //Set GPIO Pin for SCK
        GPIOPinTypeI2CSCL(GPIO_PORTE_BASE,GPIO_PIN_4);

        GPIOPinConfigure(GPIO_PE4_I2C2SCL);
        GPIOPinConfigure(GPIO_PE5_I2C2SDA );

        I2CMasterInitExpClk(I2C2_BASE, SysCtlClockGet(), false);
    }
    else if(mod == I2C3_BASE){
        SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C3);

        SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOH);

        while(!SysCtlPeripheralReady(SYSCTL_PERIPH_I2C3))
        while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOD));

        //Set GPIO Pin for SDA
        GPIOPinTypeI2C(GPIO_PORTD_BASE,GPIO_PIN_1);

        //Set GPIO Pin for SCK
        GPIOPinTypeI2CSCL(GPIO_PORTD_BASE,GPIO_PIN_0);

        GPIOPinConfigure(GPIO_PD0_I2C3SCL);
        GPIOPinConfigure(GPIO_PD1_I2C3SDA );

        I2CMasterInitExpClk(I2C3_BASE, SysCtlClockGet(), false);
    }

    // does it require GPIO pins? if so, how do we configure them?


    // you get this for free
    //I2CMasterInitExpClk(I2C_B_BASE, SysCtlClockGet(), false);
}



// I2C_WriteSingle
// Writes a single byte to an address.
// Param uint32_t "mod": base address of module
// Param uint8_t "addr": address to device
// Param uint8_t "byte": byte to send
// Return: void
void I2C_WriteSingle(uint32_t mod, uint8_t addr, uint8_t byte) {
    // which module and where to?
    I2CMasterSlaveAddrSet(mod,addr,false);


    // what data?
    I2CMasterDataPut(mod, byte);



    // what mode?
    I2CMasterControl(mod, I2C_MASTER_CMD_SINGLE_SEND);


    // should we wait till finished?
    while(I2CMasterBusy(mod));




    return;
}

// I2C_ReadSingle
// Reads a single byte from address.
// Param uint32_t "mod": base address of module
// Param uint8_t "addr": address to device
// Return: uint8_t
uint8_t I2C_ReadSingle(uint32_t mod, uint8_t addr) {
    // which module and where to? 
    I2CMasterSlaveAddrSet(mod,addr,true);


    // what data?
    //send random data
    //I2CMasterDataPut(mod, 0);


    // what mode?
    I2CMasterControl(mod, I2C_MASTER_CMD_SINGLE_RECEIVE);


    // should be wait till finished?
    while(I2CMasterBusy(mod));



    // return data from module
    return (I2CMasterDataGet(mod));
}

// I2C_WriteMultiple
// Write multiple bytes to a device.
// Param uint32_t "mod": base address of module
// Param uint8_t "addr": address to device
// Param uint8_t* "data": pointer to an array of bytes
// Param uint8_t "num_bytes": number of bytes to transmit
// Return: void
void I2C_WriteMultiple(uint32_t mod, uint8_t addr, uint8_t* data, uint8_t num_bytes) {
    // which module and where to? 


    if (num_bytes==1){
        I2C_WriteSingle(mod,addr,*data);
        return;
    }
    I2CMasterSlaveAddrSet(mod,addr,false);



    int start = 1;

    //1st Byte
    while(start !=0){
        // what data?
        //Put data at address pointed to by data
        I2CMasterDataPut(mod, *data);


        // what mode?
        //Start Burst Send I2C
        I2CMasterControl(mod, I2C_MASTER_CMD_BURST_SEND_START);


        // should be wait till finished?
        while(I2CMasterBusy(mod));

        // hint: how many times do we need to write?
        start--;

        data++;
        num_bytes--;
    }

    //Middle Bytes
    while(num_bytes >1){
            // what data?
            I2CMasterDataPut(mod, *data);


            // what mode?
            I2CMasterControl(mod, I2C_MASTER_CMD_BURST_SEND_CONT);


            // should be wait till finished?
            while(I2CMasterBusy(mod));


            // hint: how many times do we need to write?
            data++;
            num_bytes--;
      }

      // Last Byte

      // what data?
      I2CMasterDataPut(mod, *data);


      // what mode?
      // hint 2: how do we tell the module we're done sending data?
      I2CMasterControl(mod, I2C_MASTER_CMD_BURST_SEND_FINISH);


      // should be wait till finished?
      while(I2CMasterBusy(mod));



    return;
}

// I2C_ReadMultiple
// Read multiple bytes from a device.
// Param uint32_t "mod": base address of module
// Param uint8_t "addr": address to device
// Param uint8_t* "data": pointer to an array of bytes
// Param uint8_t "num_bytes": number of bytes to read
// Return: void
void I2C_ReadMultiple(uint32_t mod, uint8_t addr, uint8_t* data, uint8_t num_bytes) {
    // which module and where to? 


    if (num_bytes==1){
        *data = I2C_ReadSingle(mod,addr);
        return;
    }

    I2CMasterSlaveAddrSet(mod,addr,true);

    int start = 1;

    //1st Byte
    while(start !=0){
        // what data?
        //Put data at address pointed to by data


        // what mode?
        //Start Burst Send I2C
        I2CMasterControl(mod, I2C_MASTER_CMD_BURST_RECEIVE_START);


        // should be wait till finished?
        while(I2CMasterBusy(mod));

        *data = (I2CMasterDataGet(mod));
        // hint: how many times do we need to write?
        start--;

        data++;
        num_bytes--;
    }

    //Middle Bytes
    while(num_bytes >1){
            // what data?


            // what mode?
            I2CMasterControl(mod, I2C_MASTER_CMD_BURST_RECEIVE_CONT);


            // should be wait till finished?
            while(I2CMasterBusy(mod));

            *data = (I2CMasterDataGet(mod));
            // hint: how many times do we need to write?
            data++;
            num_bytes--;
      }

      // Last Byte

      // what data?


      // what mode?
      // hint 2: how do we tell the module we're done sending data?
      I2CMasterControl(mod, I2C_MASTER_CMD_BURST_RECEIVE_FINISH);


      // should be wait till finished?
      while(I2CMasterBusy(mod));
      *data = (I2CMasterDataGet(mod));



    return;
}

/********************************Public Functions***********************************/

